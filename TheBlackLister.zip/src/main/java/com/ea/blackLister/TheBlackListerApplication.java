package com.ea.blackLister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheBlackListerApplication {
    public static void main(String[] args) {
        SpringApplication.run(TheBlackListerApplication.class, args);
    }
}
